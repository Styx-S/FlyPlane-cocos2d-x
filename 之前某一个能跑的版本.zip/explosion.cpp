#include"explosion.h"

/*bool explosion::initWithSpriteFrameName(const std::string& frameName)
{
	if(!)
}
*/
